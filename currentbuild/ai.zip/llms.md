# hl7.fhir.no.studyfinder#0.1.0: Forskningsstudier for deltakere

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Helsestatus for studiesøk](CodeSystem-studyfinder-health-status-codes.md)

### ValueSets

* [Helsestatusverdier for studiesøk](ValueSet-studyfinder-health-status-values.md)

### Resource Profiles

* [Helsetilstand for vurdering mot studiekriterier](StructureDefinition-studyfinder-condition.md)
* [Helsestatus for potensiell studiedeltaker](StructureDefinition-studyfinder-health-status-observation.md)
* [Fysisk studiested](StructureDefinition-studyfinder-location.md)
* [Legemiddelbruk for vurdering mot studiekriterier](StructureDefinition-studyfinder-medication-statement.md)
* [Måling for vurdering mot studiekriterier](StructureDefinition-studyfinder-observation.md)
* [Organisasjon for forskningsstudie](StructureDefinition-studyfinder-organization.md)
* [Potensiell studiedeltaker](StructureDefinition-studyfinder-participant.md)
* [Svar på spørreskjema for studiesøk](StructureDefinition-studyfinder-questionnaire-response.md)
* [Spørreskjema for studiesøk](StructureDefinition-studyfinder-questionnaire.md)
* [Forskningsstudie for studiefinning](StructureDefinition-studyfinder-research-study.md)
* [Målgruppe for forskningsstudie](StructureDefinition-studyfinder-study-population.md)

### ImplementationGuides

* [Forskningsstudier for deltakere](index.md)
